#/bin/bash

make mode1_print_photo_1.out
make mode1_print_photo_2.out
make mode1_print_photo_3.out 
make mode1_print_photo_4.out     
make mode1_print_photo.out
make app 
make start

